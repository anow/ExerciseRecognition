function res = gradientsFromYpr(input)

%

input